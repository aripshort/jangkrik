import { db } from "./db";
import { chatHistory, type InsertChatMessage, type ChatMessage } from "@shared/schema";

export interface IStorage {
  getChatHistory(): Promise<ChatMessage[]>;
  addMessage(message: InsertChatMessage): Promise<ChatMessage>;
  clearHistory(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getChatHistory(): Promise<ChatMessage[]> {
    return await db.select().from(chatHistory).orderBy(chatHistory.createdAt);
  }

  async addMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const [inserted] = await db.insert(chatHistory).values(message).returning();
    return inserted;
  }

  async clearHistory(): Promise<void> {
    await db.delete(chatHistory);
  }
}

export const storage = new DatabaseStorage();
