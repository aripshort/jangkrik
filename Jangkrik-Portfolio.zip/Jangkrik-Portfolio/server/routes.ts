import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.get(api.chat.history.path, async (req, res) => {
    try {
      const history = await storage.getChatHistory();
      res.json(history);
    } catch (e) {
      res.status(500).json({ message: "Failed to fetch history" });
    }
  });

  app.post(api.chat.message.path, async (req, res) => {
    try {
      const { message } = api.chat.message.input.parse(req.body);
      
      // Add user message to db
      await storage.addMessage({ role: 'user', content: message });
      
      const history = await storage.getChatHistory();
      
      // Get system prompt context
      const systemMessage = {
        role: "system" as const,
        content: `You are an AI assistant named "jangkrik". The user who created you is a developer who likes making games, likes learning about AI, and coding for fun.
If the user asks about the creator or "About me", tell them they can find out more by clicking the "About me" button in the middle of the screen. The creator's superpower is "what I can do": making games, making websites, like to learn ai, and school children.`
      };

      const messages = [
        systemMessage,
        ...history.map(m => ({ role: m.role as "user" | "assistant", content: m.content }))
      ];

      const response = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: messages,
      });

      const aiResponse = response.choices[0]?.message?.content || "I'm sorry, I couldn't process that.";
      
      // Add AI message to db
      await storage.addMessage({ role: 'assistant', content: aiResponse });

      res.status(200).json({ response: aiResponse });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input" });
      }
      console.error(error);
      res.status(500).json({ message: "Failed to process message" });
    }
  });

  app.post(api.chat.clear.path, async (req, res) => {
    try {
      await storage.clearHistory();
      res.json({ success: true });
    } catch (e) {
      res.status(500).json({ message: "Failed to clear history" });
    }
  });

  return httpServer;
}
